package com.capgemini.hackathon.automation.main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.capgemini.hackathon.automation.model.ConfigurationModel;
import com.capgemini.hackathon.automation.util.HugeDataSetCreationUtil;

public class HackathonMain {

	private static final String MASTER_EMPLOYEE_FILE="C:\\Users\\sc4\\workspace\\DemonetizationFraudAlert\\data\\MasterEmployeeFile.csv";
	public static void main(String[] args) {
		
		HackathonMain hackthonObj = new HackathonMain();
		ConfigurationModel configModelObj =hackthonObj.loadProperties();
		HugeDataSetCreationUtil.generateSampleTxnData(MASTER_EMPLOYEE_FILE, configModelObj);
	}

	private ConfigurationModel loadProperties() {
		Properties prop = new Properties();
		InputStream input = null;
		ConfigurationModel configModelObj = null;
		try 
		{
			input = new FileInputStream("fraudAlert.properties");
			prop.load(input);
			configModelObj=populateConfigModelObj(prop);
	 	} 
		catch (FileNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
		}
		return configModelObj;
	}
	
	private ConfigurationModel populateConfigModelObj(Properties prop){
		ConfigurationModel configObj = new ConfigurationModel();
		String delimiter = prop.getProperty("FraudAlert_Delimiter");
		Long dataSize = Long.valueOf(prop.getProperty("FraudAlert_DataSize"));
		String sampleDataStartDate = prop.getProperty("FraudAlert_StartDate");
		String sampleDataEndDate = prop.getProperty("FraudAlert_EndDate");
		String demonetizationDate = prop.getProperty("FraudAlert_DemonetizationDate");
		Double lowSalary=Double.valueOf(prop.getProperty("FraudAlert_LowSalary_Threshold"));
		Double mediumSalary=Double.valueOf(prop.getProperty("FraudAlert_MediumSalary_Threshold"));
		Double highSalary=Double.valueOf(prop.getProperty("FraudAlert_HighSalary_Threshold"));
		String months =prop.getProperty("FraudAlert_months");
		String years =prop.getProperty("FraudAlert_years");
		String lowSalaryDRAndCRBefore= prop.getProperty("FraudAlert_LowSalary_Max_DRAndCR_Before");
		String mediumSalaryDRAndCRBefore= prop.getProperty("FraudAlert_MediumSalary_Max_DRAndCR_Before");
		String highSalaryDRAndCRBefore= prop.getProperty("FraudAlert_HighSalary_Max_DRAndCR_Before");
		String lowSalaryDRAndCRAfter= prop.getProperty("FraudAlert_LowSalary_Max_DRAndCR_After");
		String mediumSalaryDRAndCRAfter= prop.getProperty("FraudAlert_MediumSalary_Max_DRAndCR_After");
		String highSalaryDRAndCRAfter= prop.getProperty("FraudAlert_HighSalary_Max_DRAndCR_After");
		
		String month[] = months.split(",");
		List<Integer> monthsArrList  = new ArrayList<Integer>(months.length());
		for (int i = 0; i < month.length; i++) {
			monthsArrList.add(Integer.valueOf(month[i]));
		}
		String year[] = months.split(",");
		List<Integer> yearsArrList  = new ArrayList<Integer>(years.length());
		for (int i = 0; i < year.length; i++) {
			yearsArrList.add(Integer.valueOf(year[i]));
		}
		configObj.setDelimiter(delimiter);
		configObj.setDataSize(dataSize);
		configObj.setSampleDataStartDate(sampleDataStartDate);
		configObj.setSampleDataEndDate(sampleDataEndDate);
		configObj.setDemonetizationThresoldDate(demonetizationDate);
		configObj.setMaxLowSalaryRange(lowSalary);
		configObj.setMaxMediumSalaryRange(mediumSalary);
		configObj.setMaxHighSalaryRange(highSalary);
		configObj.setMonths(monthsArrList);
		configObj.setYears(yearsArrList);
		configObj.setLowSalaryDRAndCRBefore(getDRAndCR(lowSalaryDRAndCRBefore));
		configObj.setMediumSalaryDRAndCRBefore(getDRAndCR(mediumSalaryDRAndCRBefore));
		configObj.setHighSalaryDRAndCRBefore(getDRAndCR(highSalaryDRAndCRBefore));
		configObj.setLowSalaryDRAndCRAfter(getDRAndCR(lowSalaryDRAndCRAfter));
		configObj.setMediumSalaryDRAndCRAfter(getDRAndCR(mediumSalaryDRAndCRAfter));
		configObj.setHighSalaryDRAndCRAfter(getDRAndCR(highSalaryDRAndCRAfter));
		
		return configObj;
	}
	
	private List<Integer> getDRAndCR(String txnDRAndCR) {
		List<Integer> salaryDrAndCrList = new ArrayList<Integer>();
		String txnDRAndCRStrArr [] = txnDRAndCR.split(",");
		for (int count = 0; count < txnDRAndCRStrArr.length; count++) {
			Integer value = Integer.valueOf(txnDRAndCRStrArr[count]);
			salaryDrAndCrList.add(value);
		}
		return salaryDrAndCrList;
	}
}
