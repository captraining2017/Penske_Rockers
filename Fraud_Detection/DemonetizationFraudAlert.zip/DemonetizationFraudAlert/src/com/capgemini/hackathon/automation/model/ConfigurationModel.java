package com.capgemini.hackathon.automation.model;

import java.util.List;

public class ConfigurationModel {
	private String delimiter;
	private Long dataSize;
	private String sampleDataStartDate;
	private String sampleDataEndDate;
	private String demonetizationThresoldDate;
	private Double maxLowSalaryRange;
	private Double maxMediumSalaryRange;
	private Double maxHighSalaryRange;
	private List<Integer> months;
	private List<Integer>years;
	private List<Integer> lowSalaryDRAndCRBefore;
	private List<Integer> mediumSalaryDRAndCRBefore;
	private List<Integer> highSalaryDRAndCRBefore;
	private List<Integer> lowSalaryDRAndCRAfter;
	private List<Integer> mediumSalaryDRAndCRAfter;
	private List<Integer> highSalaryDRAndCRAfter;
	public String getDelimiter() {
		return delimiter;
	}
	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}
	public Long getDataSize() {
		return dataSize;
	}
	public void setDataSize(Long dataSize) {
		this.dataSize = dataSize;
	}
	public String getSampleDataStartDate() {
		return sampleDataStartDate;
	}
	public void setSampleDataStartDate(String sampleDataStartDate) {
		this.sampleDataStartDate = sampleDataStartDate;
	}
	public String getSampleDataEndDate() {
		return sampleDataEndDate;
	}
	public void setSampleDataEndDate(String sampleDataEndDate) {
		this.sampleDataEndDate = sampleDataEndDate;
	}
	public String getDemonetizationThresoldDate() {
		return demonetizationThresoldDate;
	}
	public void setDemonetizationThresoldDate(String demonetizationThresoldDate) {
		this.demonetizationThresoldDate = demonetizationThresoldDate;
	}
	public Double getMaxLowSalaryRange() {
		return maxLowSalaryRange;
	}
	public void setMaxLowSalaryRange(Double maxLowSalaryRange) {
		this.maxLowSalaryRange = maxLowSalaryRange;
	}
	public Double getMaxMediumSalaryRange() {
		return maxMediumSalaryRange;
	}
	public void setMaxMediumSalaryRange(Double maxMediumSalaryRange) {
		this.maxMediumSalaryRange = maxMediumSalaryRange;
	}
	public Double getMaxHighSalaryRange() {
		return maxHighSalaryRange;
	}
	public void setMaxHighSalaryRange(Double maxHighSalaryRange) {
		this.maxHighSalaryRange = maxHighSalaryRange;
	}
	public List<Integer> getMonths() {
		return months;
	}
	public void setMonths(List<Integer> months) {
		this.months = months;
	}
	public List<Integer> getYears() {
		return years;
	}
	public void setYears(List<Integer> years) {
		this.years = years;
	}
	public List<Integer> getLowSalaryDRAndCRBefore() {
		return lowSalaryDRAndCRBefore;
	}
	public void setLowSalaryDRAndCRBefore(List<Integer> lowSalaryDRAndCRBefore) {
		this.lowSalaryDRAndCRBefore = lowSalaryDRAndCRBefore;
	}
	public List<Integer> getMediumSalaryDRAndCRBefore() {
		return mediumSalaryDRAndCRBefore;
	}
	public void setMediumSalaryDRAndCRBefore(List<Integer> mediumSalaryDRAndCRBefore) {
		this.mediumSalaryDRAndCRBefore = mediumSalaryDRAndCRBefore;
	}
	public List<Integer> getHighSalaryDRAndCRBefore() {
		return highSalaryDRAndCRBefore;
	}
	public void setHighSalaryDRAndCRBefore(List<Integer> highSalaryDRAndCRBefore) {
		this.highSalaryDRAndCRBefore = highSalaryDRAndCRBefore;
	}
	public List<Integer> getLowSalaryDRAndCRAfter() {
		return lowSalaryDRAndCRAfter;
	}
	public void setLowSalaryDRAndCRAfter(List<Integer> lowSalaryDRAndCRAfter) {
		this.lowSalaryDRAndCRAfter = lowSalaryDRAndCRAfter;
	}
	public List<Integer> getMediumSalaryDRAndCRAfter() {
		return mediumSalaryDRAndCRAfter;
	}
	public void setMediumSalaryDRAndCRAfter(List<Integer> mediumSalaryDRAndCRAfter) {
		this.mediumSalaryDRAndCRAfter = mediumSalaryDRAndCRAfter;
	}
	public List<Integer> getHighSalaryDRAndCRAfter() {
		return highSalaryDRAndCRAfter;
	}
	public void setHighSalaryDRAndCRAfter(List<Integer> highSalaryDRAndCRAfter) {
		this.highSalaryDRAndCRAfter = highSalaryDRAndCRAfter;
	}
	
	
	
	
}
