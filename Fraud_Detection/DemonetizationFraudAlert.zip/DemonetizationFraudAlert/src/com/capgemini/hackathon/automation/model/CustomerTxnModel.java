package com.capgemini.hackathon.automation.model;

public class CustomerTxnModel {

}
