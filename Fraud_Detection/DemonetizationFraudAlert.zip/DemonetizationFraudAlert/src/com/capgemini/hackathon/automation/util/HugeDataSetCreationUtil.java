package com.capgemini.hackathon.automation.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import com.capgemini.hackathon.automation.model.ConfigurationModel;
import com.capgemini.hackathon.automation.model.Employee;

public class HugeDataSetCreationUtil {

	private static final String COMMA_DELIMITER = ",";
	private static final String FILE_HEADER = "Cust Id,Txn Date,Txn Amount,DR/CR";
	private static final String NEW_LINE_SEPARATOR = "\n";


	
	public static void generateSampleTxnData(String masterEmpFileName, ConfigurationModel configObj, String txnFilePath) {
		List<Employee> employeeList = getEmployeeModelList(masterEmpFileName);
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(txnFilePath);
			fileWriter.append(FILE_HEADER.toString());
			fileWriter.append(NEW_LINE_SEPARATOR);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for (int yearCount = 0; yearCount < configObj.getYears().size(); yearCount++) {
			for (int monthCount = 0; monthCount < configObj.getMonths().size(); monthCount++) {
				int year=configObj.getYears().get(yearCount);
				int month=configObj.getMonths().get(monthCount);
				Date firstDateOfMonth = DateUtil.getFirstMonthOfDate(year,month);
				List<Date> eachMonthDates = DateUtil.getMonthDateList(month, firstDateOfMonth);
				Random randomizer = new Random();
				Date randomDate=eachMonthDates.get(randomizer.nextInt(eachMonthDates.size()));
				Employee randomEmployee=employeeList.get(randomizer.nextInt(employeeList.size()));
				
			}
		}
		
		
		
	}
	
	private static List<Employee> getEmployeeModelList(String masterEmpFileName){
		List<Employee> employeeList = new ArrayList<Employee>();
		FileReader fileReader = null;
		BufferedReader bufReader = null;
		try 
		{
			String line = "";
			fileReader = new FileReader(masterEmpFileName);
			bufReader = new BufferedReader(fileReader);
			//Read the CSV file header to skip it
			bufReader.readLine();
			while ((line = bufReader.readLine()) != null) {
				                //Get all tokens available in line
		         String[] tokens = line.split(COMMA_DELIMITER);
		         if (tokens != null & tokens.length >0) {
		        	 for (int i = 0; i < tokens.length; i++) {
						Employee employee = new Employee();
						employee.setEmployeeId(Integer.valueOf(tokens[0]));
						employee.setEmployeeName((tokens[1]));
						employee.setSalary(Double.valueOf(tokens[2]));
						employeeList.add(employee);
					}
					
				}
			}

		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally {
			
		}

		return employeeList;
	}
	
	private static void writeTxnFile(FileWriter fileWriter, Date txnDate, Employee employee) {
		
		try {
			
			fileWriter.append(String.valueOf(employee.getEmployeeId()));
			//fileWriter.append(arg0)
			
            //Add a new line separator after the header
             

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
