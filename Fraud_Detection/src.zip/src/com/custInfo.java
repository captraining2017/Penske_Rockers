package com;

import java.io.Serializable;

public class custInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7897904673534191877L;	
	private String customerName;
	private double salary;
	private boolean isFraud;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	public boolean isFraud() {
		return isFraud;
	}
	public void setFraud(boolean isFraud) {
		this.isFraud = isFraud;
	}

}
