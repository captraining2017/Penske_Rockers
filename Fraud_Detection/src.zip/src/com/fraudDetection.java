package com;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class fraudDetection {

	public static void main(String[] args) {
		
		
		
        String csvFile = "D:\\Users\\irajasek\\Documents\\testData.csv"; 
        // "C:\Users\irajasek\workspace\Fraud_Detection\src\data\testData.csv"
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
               
        
        Map<Long,Map<String, dailyTransaction>> custTransMap = null; 
        
        Map<Long,Map<String, dailyTransaction>> custMonTransMap = null; 

        try {

            br = new BufferedReader(new FileReader(csvFile));
            if ((line = br.readLine()) != null) {
            	// String[] headers = line.split(cvsSplitBy);
            }
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] data = line.split(cvsSplitBy);
                
                System.out.println("CustID = " + data[0] + " Date [code= " + data[2]);          
                SimpleDateFormat sdf = new SimpleDateFormat ("dd-MMM-yyyy"); //("dd-M-yyyy hh:mm:ss");
                Date date = null;
				try {
					date = sdf.parse(data[2]);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				sdf.applyPattern("dd-MM-yyyy");
				//System.out.println("Date converted [code= " + date + "formatted value : " +sdf.format(date));
				String dateStr = sdf.format(date);
			
				//
				String month[] = sdf.format(date).split("-");
				System.out.println("Month =  " +month[1]); 
				
				
				if (custMonTransMap != null) {
					System.out.println("custMonTransMap != null Cust ID : " +data[0]);
					System.out.println("Is customer present : " +custMonTransMap.containsKey(Long.parseLong(data[0])));
					if (custMonTransMap.containsKey(Long.parseLong(data[0])) ) {
						HashMap<String, dailyTransaction> monthTrans = (HashMap<String, dailyTransaction>) custMonTransMap.get(Long.parseLong(data[0]));
						System.out.println("Is month present : " +monthTrans.containsKey(month[1]));
	                	if (monthTrans.containsKey(month[1])) {
	                		dailyTransaction monTrans = monthTrans.get(month[1]);	                		
	                		if (!data[3].isEmpty()) {   
	                			System.out.println("monTrans.getDebitCount() : " +monTrans.getDebitCount());
	                			monTrans.setDebitCount(monTrans.getDebitCount() + 1);    
	                			System.out.println("monTrans.getTotalDebits() : " +monTrans.getTotalDebits());
	                			monTrans.setTotalDebits(monTrans.getTotalDebits() + (Double.parseDouble(data[3])));
                			}
	                		System.out.println("data length : " +data.length);
	                		if (data.length == 5 && !data[4].isEmpty()) {  
	                			System.out.println("monTrans.getCreditCount() : " +monTrans.getCreditCount());
	                			monTrans.setCreditCount(monTrans.getCreditCount() + 1); 
	                			System.out.println("monTrans.getTotalCredits() : " +monTrans.getTotalCredits());
	                			monTrans.setTotalCredits(monTrans.getTotalCredits() + (Double.parseDouble(data[4])));
                			}
	                		
	                		monthTrans.replace(month[1], monTrans);
	                		custMonTransMap.replace(Long.parseLong(data[0]), monthTrans);
	                		
	                	} else {
                			dailyTransaction monTrans =  new dailyTransaction();
                			
                			if (!data[3].isEmpty()) {                				
                				monTrans.setDebitCount(1); 
                				System.out.println("monTrans.getDebitCount() : " +monTrans.getDebitCount());
                				monTrans.setTotalDebits((Double.parseDouble(data[3])));
                				System.out.println("monTrans.getTotalDebits() : " +monTrans.getTotalDebits());
                				monTrans.setCreditCount(0); 
                			}
                			
                			if (data.length == 5 && !data[4].isEmpty()) {                				
                				monTrans.setCreditCount(1);  
                				System.out.println("monTrans.getCreditCount() : " +monTrans.getCreditCount());
                				monTrans.setTotalCredits((Double.parseDouble(data[4])));
                				System.out.println("monTrans.getTotalCredits() : " +monTrans.getTotalCredits());
                				monTrans.setDebitCount(0); 
                			}
                			
                			monthTrans.put(month[1], monTrans);
                			custMonTransMap.put(Long.parseLong(data[0]), monthTrans); 
                		}
					} else {
						HashMap<String, dailyTransaction> monthTrans = new HashMap<String, dailyTransaction>();
                		dailyTransaction monTrans =  new dailyTransaction();                		
            			if (!data[3].isEmpty()) {            				
            				monTrans.setDebitCount(1);                				
            				monTrans.setTotalDebits((Double.parseDouble(data[3])));
            				monTrans.setCreditCount(0); 
            			}
            			
            			if (data.length == 5 && !data[4].isEmpty()) {            				
            				monTrans.setCreditCount(1);                				
            				monTrans.setTotalCredits((Double.parseDouble(data[4])));
            				monTrans.setDebitCount(0);  
            			}              			
                		
            			monthTrans.put(month[1], monTrans);
                			
            			custMonTransMap.put(Long.parseLong(data[0]), monthTrans);
                	
					}
				} else {
					System.out.println("custMonTransMap = null");					
                	
					custMonTransMap = new HashMap<Long,Map<String, dailyTransaction>>();
					HashMap<String, dailyTransaction> monthTrans = new HashMap<String, dailyTransaction>();
                		dailyTransaction monTrans =  new dailyTransaction();                		
            			if (!data[3].isEmpty()) {            				
            				monTrans.setDebitCount(1);   
            				System.out.println("monTrans.getDebitCount() : " +monTrans.getDebitCount());
            				monTrans.setTotalDebits((Double.parseDouble(data[3])));
            				System.out.println("monTrans.getTotalDebits() : " +monTrans.getTotalDebits());
            				monTrans.setCreditCount(0); 
            			}
            			
            			if (data.length == 5 && !data[4].isEmpty()) {            				
            				monTrans.setCreditCount(1); 
            				System.out.println("monTrans.getCreditCount() : " +monTrans.getCreditCount());
            				monTrans.setTotalCredits((Double.parseDouble(data[4])));
            				System.out.println("monTrans.getTotalCredits() : " +monTrans.getTotalCredits());
            				monTrans.setDebitCount(0);  
            			}              			
            				System.out.println("month[1] = " +month[1]);	
            				monthTrans.put(month[1], monTrans);
                			
            				custMonTransMap.put(Long.parseLong(data[0]), monthTrans); 
					
				}
				
				
				
				
// STEP 2				
                // System.out.println(date); //Tue Aug 31 10:20:56 SGT 1982
				/*System.out.println(custTransMap);
                if (custTransMap != null) {
                	System.out.println("custTransMap != null");
                	HashMap<String, dailyTransaction> dailyTrans = new HashMap<String, dailyTransaction>();
                	if (custTransMap.containsKey(Long.parseLong(data[0])) ) {
                		dailyTrans = (HashMap<String, dailyTransaction>) custTransMap.get(Long.parseLong(data[0]));
                		if (dailyTrans.containsKey(dateStr)) {
                			dailyTransaction trans = dailyTrans.get(dateStr);
                			if (!data[3].isEmpty()) {                				
                				trans.setDebitCount(trans.getDebitCount() + 1);                				
                				trans.setTotalDebits(trans.getTotalDebits() + (Double.parseDouble(data[3])));
                			}
                			
                			if (data.length == 5 && !data[4].isEmpty()) {                				
                				trans.setCreditCount(trans.getCreditCount() + 1);                				
                				trans.setTotalCredits(trans.getTotalCredits() + (Double.parseDouble(data[4])));
                			}
                			
                		} else {
                			dailyTransaction trans =  new dailyTransaction();
                			
                			if (!data[3].isEmpty()) {                				
                				trans.setDebitCount(1);                				
                				trans.setTotalDebits((Double.parseDouble(data[3])));
                				trans.setCreditCount(0); 
                			}
                			
                			if (data.length == 5 && !data[4].isEmpty()) {                				
                				trans.setCreditCount(1);                				
                				trans.setTotalCredits((Double.parseDouble(data[4])));
                				trans.setDebitCount(0); 
                			}
                			
                			dailyTrans.put(dateStr, trans);
                			custTransMap.put(Long.parseLong(data[0]), dailyTrans); 
                		}
                	} else {
                		dailyTrans = new HashMap<String, dailyTransaction>();
                		dailyTransaction trans =  new dailyTransaction();                		
            			if (!data[3].isEmpty()) {            				
            				trans.setDebitCount(1);                				
            				trans.setTotalDebits((Double.parseDouble(data[3])));
            				trans.setCreditCount(0); 
            			}
            			
            			if (data.length == 5 && !data[4].isEmpty()) {            				
            				trans.setCreditCount(1);                				
            				trans.setTotalCredits((Double.parseDouble(data[4])));
            				trans.setDebitCount(0);  
            			}              			
                		
                			dailyTrans.put(dateStr, trans);
                			
                			custTransMap.put(Long.parseLong(data[0]), dailyTrans);
                	}
                	
                } else {                	
                	custTransMap = new HashMap<Long,Map<String, dailyTransaction>>();
                		HashMap<String, dailyTransaction> dailyTrans = new HashMap<String, dailyTransaction>();
                		dailyTransaction trans =  new dailyTransaction();                		
            			if (!data[3].isEmpty()) {            				
            				trans.setDebitCount(1);                				
            				trans.setTotalDebits((Double.parseDouble(data[3])));
            				trans.setCreditCount(0); 
            			}
            			
            			if (data.length == 5 && !data[4].isEmpty()) {            				
            				trans.setCreditCount(1);                				
            				trans.setTotalCredits((Double.parseDouble(data[4])));
            				trans.setDebitCount(0);  
            			}              			
                		
                			dailyTrans.put(dateStr, trans);
                			
                			custTransMap.put(Long.parseLong(data[0]), dailyTrans);                		
                	}  */             	
                
                }   

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
       /* if (custTransMap != null) {
        	System.out.println("DAily Map is NOT NULL");
        	for (Entry<Long, Map<String, dailyTransaction>> entry : custTransMap.entrySet()) {
        		System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());
        		Map<String, dailyTransaction> dailyTrans = (Map<String, dailyTransaction>) entry.getValue() ;
        		for (Entry<String, dailyTransaction> entry1 : dailyTrans.entrySet()) {
        			System.out.println("Key : " + entry1.getKey() + " Value : " + entry1.getValue());
        			dailyTransaction trans =  (dailyTransaction) (entry1.getValue()) ;
        			System.out.println("Total Credits : " + trans.getTotalCredits() + " Credit Count : " + trans.getCreditCount()
        			+ " Total Debits : " + trans.getTotalDebits() + " Debit Count : " + trans.getDebitCount());
        		}
        	}
        } else {
        	System.out.println("DAily Map is NULL");
        }*/
        
        if (custMonTransMap != null) {
        	System.out.println("Monthly Map is NOT NULL");
        	for (Entry<Long, Map<String, dailyTransaction>> entry : custMonTransMap.entrySet()) {
        		System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());
        		Map<String, dailyTransaction> monthTrans = (Map<String, dailyTransaction>) entry.getValue() ;
        		for (Entry<String, dailyTransaction> entry1 : monthTrans.entrySet()) {
        			System.out.println("Key : " + entry1.getKey() + " Value : " + entry1.getValue());
        			dailyTransaction monTrans =  (dailyTransaction) (entry1.getValue()) ;
        			System.out.println("MOnthly Total Credits : " + monTrans.getTotalCredits() + " MOnthly Credit Count : " + monTrans.getCreditCount()
        			+ " MOnthly Total Debits : " + monTrans.getTotalDebits() + " MOnthly Debit Count : " + monTrans.getDebitCount());
        		}
        	}
        } else {
        	System.out.println("Monthly Map is NULL");
        }
        
        
      /*  csvFile = "C:\\Users\\irajasek\\workspace\\Fraud_Detection\\src\\data\\custMaster.csv"; 
        // "C:\Users\irajasek\workspace\Fraud_Detection\src\data\testData.csv"
        br = null;
        Map<Long,custInfo> customerInfo = null; 
        try {

            br = new BufferedReader(new FileReader(csvFile));
            if ((line = br.readLine()) != null) {
            	// String[] headers = line.split(cvsSplitBy);
            }
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] data = line.split(cvsSplitBy);
                
                if (customerInfo != null) {
                	System.out.println("customerInfo != null");
                	if (customerInfo.containsKey(Long.parseLong(data[0])) ) {
                		;
                	} else {
                		custInfo custDet = new custInfo();
                		custDet.setCustomerName(data[1]);
                		custDet.setSalary(Long.parseLong(data[2]));
                		custDet.setFraud(false);
                		customerInfo.put(Long.parseLong(data[0]), custDet);
                	}
                } else {
                	System.out.println("customerInfo = null");
                	
                	customerInfo = new HashMap<Long,custInfo>();
                	
                	custInfo custDet = new custInfo();
            		custDet.setCustomerName(data[1]);
            		custDet.setSalary(Long.parseLong(data[2]));
            		custDet.setFraud(false);
            		customerInfo.put(Long.parseLong(data[0]), custDet);
                }
            }
            
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        
        if (customerInfo != null) {
        	for (Entry<Long, custInfo> entry : customerInfo.entrySet()) {
        		System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());
        		custInfo custSum = (custInfo) entry.getValue() ;        		
        			System.out.println("Name : " + custSum.getCustomerName() + " Salary : " + custSum.getSalary());
        			System.out.println("Is Fraud : " + custSum.isFraud());
        		
        	}
        } else {
        	System.out.println("Map is NULL");
        }
        */
        
        
    }

	
    
}
